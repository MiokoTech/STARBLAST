package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.SharedPreferences;
import android.net.Uri;

import com.adobe.fre.*;

public class CheckUriFunction implements FREFunction {
    @Override
    public FREObject call(FREContext ctx, FREObject[] args) {
        try {
            Activity activity = ctx.getActivity();
            SharedPreferences prefs = activity.getSharedPreferences("storage_access", Activity.MODE_PRIVATE);
            String uriStr = prefs.getString("tree_uri", null);
            return FREObject.newObject(uriStr != null && !uriStr.isEmpty());
        } catch (Exception e) {
            e.printStackTrace();
            try {
                return FREObject.newObject(false);
            } catch (FREWrongThreadException ex) {
                ex.printStackTrace();
                return null;
            }
        }
    }
}
