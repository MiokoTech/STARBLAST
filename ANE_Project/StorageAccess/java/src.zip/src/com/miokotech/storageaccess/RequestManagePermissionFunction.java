package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.adobe.fre.*;

public class RequestManagePermissionFunction implements FREFunction {

    @Override
    public FREObject call(FREContext freContext, FREObject[] args) {
        try {
            Activity activity = freContext.getActivity();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(intent);
            }

            return FREObject.newObject(true);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                return FREObject.newObject(false);
            } catch (FREWrongThreadException ignored) {
                return null;
            }
        }
    }
}
