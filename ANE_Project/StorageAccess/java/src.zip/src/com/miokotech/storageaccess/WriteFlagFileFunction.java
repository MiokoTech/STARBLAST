package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.adobe.fre.*;

import java.io.OutputStream;

public class WriteFlagFileFunction implements FREFunction {

    @Override
    public FREObject call(FREContext freContext, FREObject[] args) {
        try {
            Activity activity = freContext.getActivity();
            SharedPreferences prefs = activity.getSharedPreferences("storage_access", Activity.MODE_PRIVATE);
            String uriStr = prefs.getString("tree_uri", null);

            if (uriStr == null) {
                return FREObject.newObject(false);
            }

            Uri treeUri = Uri.parse(uriStr);
            ContentResolver resolver = activity.getContentResolver();

            // Membuat file baru bernama .storage_selected.txt di folder SAF
            Uri docUri = DocumentsContract.createDocument(
                resolver,
                treeUri,
                "text/plain",
                ".storage_selected.txt"
            );

            if (docUri != null) {
                OutputStream out = resolver.openOutputStream(docUri);
                if (out != null) {
                    out.write("true".getBytes());
                    out.close();
                    return FREObject.newObject(true);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            return FREObject.newObject(false);
        } catch (FREWrongThreadException e) {
            e.printStackTrace();
            return null;
        }
    }
}
