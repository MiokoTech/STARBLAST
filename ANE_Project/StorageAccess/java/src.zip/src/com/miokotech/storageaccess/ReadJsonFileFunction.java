package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.adobe.fre.*;

import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ReadJsonFileFunction implements FREFunction {
    @Override
    public FREObject call(FREContext ctx, FREObject[] args) {
        try {
            if (args.length < 1) return FREObject.newObject("");

            String fileName = args[0].getAsString(); // misal: settings.json

            Activity activity = ctx.getActivity();
            SharedPreferences prefs = activity.getSharedPreferences("storage_access", Activity.MODE_PRIVATE);
            String uriStr = prefs.getString("starblast_uri", null);
            if (uriStr == null) return FREObject.newObject("");

            Uri treeUri = Uri.parse(uriStr);
            ContentResolver resolver = activity.getContentResolver();

            // Cari file berdasarkan nama
            Uri fileUri = SAFUtils.findFileUri(resolver, treeUri, fileName);
            if (fileUri == null) return FREObject.newObject("");

            InputStream in = resolver.openInputStream(fileUri);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line).append("\n");
            }
            reader.close();
            in.close();

            return FREObject.newObject(result.toString().trim());
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            return FREObject.newObject("");
        } catch (FREWrongThreadException e) {
            return null;
        }
    }
}
