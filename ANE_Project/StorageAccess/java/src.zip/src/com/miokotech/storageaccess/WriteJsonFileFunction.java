package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.adobe.fre.*;

import java.io.OutputStream;

public class WriteJsonFileFunction implements FREFunction {
    @Override
    public FREObject call(FREContext ctx, FREObject[] args) {
        try {
            if (args.length < 2) return FREObject.newObject(false);

            String fileName = args[0].getAsString(); // Contoh: "settings.json"
            String jsonContent = args[1].getAsString();

            Activity activity = ctx.getActivity();
            SharedPreferences prefs = activity.getSharedPreferences("storage_access", Activity.MODE_PRIVATE);
            String uriStr = prefs.getString("starblast_uri", null);
            if (uriStr == null) return FREObject.newObject(false);

            Uri treeUri = Uri.parse(uriStr);
            ContentResolver resolver = activity.getContentResolver();

            // Buat dokumen baru atau timpa yang lama
            Uri docUri = DocumentsContract.createDocument(
                    resolver,
                    treeUri,
                    "application/json",
                    fileName
            );

            if (docUri != null) {
                OutputStream out = resolver.openOutputStream(docUri);
                out.write(jsonContent.getBytes("UTF-8"));
                out.close();
                return FREObject.newObject(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            return FREObject.newObject(false);
        } catch (FREWrongThreadException e) {
            return null;
        }
    }
}
