package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.adobe.fre.*;

public class PersistUriFunction implements FREFunction {
    @Override
    public FREObject call(FREContext ctx, FREObject[] args) {
        try {
            Activity activity = ctx.getActivity();
            ContentResolver resolver = activity.getContentResolver();
            String uriStr = args[0].getAsString();
            Uri treeUri = Uri.parse(uriStr);

            // Ambil izin permanen
            resolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            );

            // Simpan tree_uri
            SharedPreferences prefs = activity.getSharedPreferences("storage_access", Activity.MODE_PRIVATE);
            prefs.edit().putString("tree_uri", treeUri.toString()).apply();

            Uri starblastUri = null;

            // Jika belum ada, buat folder STARBLAST
            starblastUri = DocumentsContract.createDocument(
                resolver,
                treeUri,
                DocumentsContract.Document.MIME_TYPE_DIR,
                "STARBLAST"
            );

            // Simpan uri STARBLAST
            prefs.edit().putString("starblast_uri", starblastUri.toString()).apply();

            return FREObject.newObject(treeUri.toString());

        } catch (Exception e) {
            e.printStackTrace();
            try {
                return FREObject.newObject("");
            } catch (FREWrongThreadException freError) {
                freError.printStackTrace();
                return null;
            }
        }
    }
}
