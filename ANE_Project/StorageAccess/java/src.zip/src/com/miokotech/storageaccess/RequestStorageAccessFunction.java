package com.miokotech.storageaccess;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;

import com.adobe.fre.*;

public class RequestStorageAccessFunction implements FREFunction {
    @Override
    public FREObject call(FREContext ctx, FREObject[] args) {
        Activity activity = ctx.getActivity();
        SharedPreferences prefs = activity.getSharedPreferences("storage_access", Activity.MODE_PRIVATE);
        String uriStr = prefs.getString("tree_uri", null);

        if (uriStr != null && !uriStr.isEmpty()) {
            try {
                Uri uri = Uri.parse(uriStr);
                activity.getContentResolver().openInputStream(uri).close();
                return null;
            } catch (Exception e) {
                prefs.edit().remove("tree_uri").apply();
            }
        }

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                        Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        activity.startActivityForResult(intent, StorageAccessContext.REQUEST_CODE);
        return null;
    }
}
